<?php
include_once "dbc.inc.php";

try {
    if (isset($_POST['firstName'], $_POST['middleName'], $_POST['lastName'], $_POST['suffix'], $_POST['birthday'], $_POST['address'], $_POST['contactNumber'], $_FILES['profilePicture'], $_POST['emailAddress'], $_POST['password'])) 
    {
        $firstName = $_POST['firstName'];
        $middleName = $_POST['middleName'];
        $lastName = $_POST['lastName'];
        $suffix = $_POST['suffix'];
        $birthday = $_POST['birthday'];
        $address = $_POST['address'];
        $contactNumber = $_POST['contactNumber'];
        $emailAddress = $_POST['emailAddress'];
        $password = $_POST['password'];

        $profilePicture = ''; // Initialize profile picture variable
        if (isset($_FILES['profilePicture']['name']) && !empty($_FILES['profilePicture']['name'])) {
            $img_name = $_FILES['profilePicture']['name'];
            $tmp_name = $_FILES['profilePicture']['tmp_name'];
            $error = $_FILES['profilePicture']['error'];

            if ($error === 0) {
                $img_ex = pathinfo($img_name, PATHINFO_EXTENSION);
                $img_ex_to_lc = strtolower($img_ex);

                $allowed_exs = array('jpg', 'jpeg', 'png');
                if (in_array($img_ex_to_lc, $allowed_exs)) 
                {
                    $img_data = file_get_contents($tmp_name); // Read the image data
                    $profilePicture = $img_data; // Assign the image data to the profile picture variable
                } 
                else 
                {
                    throw new Exception("Allowed formats are: JPG, JPEG, PNG.");
                }
            } 
            else 
            {
                throw new Exception("Error! Uploading profile picture.");
            }
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO users (firstName, middleName, lastName, suffix, birthday, address, contactNumber, profilePicture, emailAddress, password) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        $stmt->execute([$firstName, $middleName, $lastName, $suffix, $birthday, $address, $contactNumber, $profilePicture, $emailAddress, $hashedPassword]);

        if ($stmt->rowCount() > 0) {
            echo "<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js'></script>";
            echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
            echo "<script>
                    $(document).ready(function() {
                        Swal.fire({
                            title: 'Successfully registered',
                            text: 'Your registration was successful.',
                            icon: 'success'
                        }).then(function() {
                            window.location.href = '../login.php';
                        });
                    });
                </script>";
        } else {
            throw new Exception("Registration failed. Please try again.");
        }
    } else {
        throw new Exception("Missing required fields.");
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>