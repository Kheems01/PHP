<?php

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once "dbc.inc.php";

    $emailAddress = $_POST['emailAddress'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE emailAddress = :emailAddress";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':emailAddress', $emailAddress);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $storedPassword = $user['password'];
        if (password_verify($password, $storedPassword)) {
            $_SESSION['firstName'] = $user['firstName'];
            $_SESSION['emailAddress'] = $user['emailAddress'];

            echo "<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js'></script>";
            echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
            echo "<script>
                    $(document).ready(function() {
                        Swal.fire({
                            title: 'Login Successful',
                            text: 'You have successfully logged in.',
                            icon: 'success'
                        }).then(function() {
                            window.location.href = '../index.php';
                        });
                    });
                </script>";
        } else {
            $_SESSION['error'] = "Password is Incorrect";
            header("Location: ../login.php");
            exit;
        }
    }
} else {
    header("Location: ../login.php");
    exit;
}