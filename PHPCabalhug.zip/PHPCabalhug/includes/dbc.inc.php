<?php
$db = "mysql:host=localhost;dbname=useraccounts";
$dbusername = "root";
$dbpassword = "";

try 
{
    $conn = new PDO($db, $dbusername, $dbpassword);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} 
catch (PDOException $e) 
{
    echo "Connection failed: " . $e->getMessage();
    exit;
}
?>
