<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="card shadow p-3 mb-5">
            <div class="card-body">
                <h2 class="card-title text-center">Registration Form</h2>
                <form id="registrationForm" action="includes/register.inc.php" method="post" enctype="multipart/form-data">
                    <div id="page1">
                        <div class="mb-3 user-box">
                            <label for="firstName">First Name</label>
                            <input type="text" class="form-control" id="firstName" name="firstName" required>

                            <label for="middleName">Middle Name</label>
                            <input type="text" class="form-control" id="middleName" name="middleName">

                            <label for="lastName">Last Name</label>
                            <input type="text" class="form-control" id="lastName" name="lastName" required>

                            <label for="suffix">Suffix</label>
                            <input type="text" class="form-control" id="suffix" name="suffix">

                            <label for="birthday">Birthday</label>
                            <input type="date" class="form-control" id="birthday" name="birthday" required>

                            <label for="address">Address</label>
                            <input type="text" class="form-control" id="address" name="address" required>

                            <label for="contactNumber">Phone Number</label>
                            <input type="text" class="form-control" id="contactNumber" name="contactNumber" required>

                            <label class="custom-file-label" for="profilePicture">Profile Picture</label>
                            <input type="file" class="form-control custom-file-input" id="profilePicture" name="profilePicture" accept="image/*" required>

                            <label for="emailAddressReg">Email Address</label>
                            <input type="email" class="form-control" id="emailAddress" name="emailAddress" required>

                            <label for="passwordReg">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                            <div class="text-end mt-3">
                    <a href="login.php" class="btn btn-outline-primary btn-lg">Sign In</a>
                    <button type="submit" id="registerButton" class="btn btn-primary btn-lg">Register</button>
                </div>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</body>
</html>