<?php
session_start();

if (isset($_SESSION['firstName'], $_SESSION['emailAddress'])) {
    $firstName = $_SESSION['firstName'];
    $emailAddress = $_SESSION['emailAddress'];

    // Fetch additional user details from the database based on the email address
    require_once "includes/dbc.inc.php";

    $sql = "SELECT * FROM users WHERE emailAddress = :emailAddress";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':emailAddress', $emailAddress);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
        .user-details {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            text-align: center;
        }

        .profile-image {
            width: 200px;
            height: 200px;
            display: block;
            margin: 0 auto 50px;
            object-fit: cover;
            border-radius: 50%;
        }

        .logout-link {
            display: block;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="user-details">
        <?php if (isset($user)): ?>
            <?php if (!empty($user['profilePicture'])): ?>
                <?php
                $imageData = base64_encode($user['profilePicture']);
                $imageType = pathinfo($user['profilePicture'], PATHINFO_EXTENSION);
                ?>
                <img class="profile-image" src="data:image/<?php echo $imageType; ?>;base64,<?php echo $imageData; ?>" alt="Profile Picture">
            <?php else: ?>
                <p>No profile picture available</p>
            <?php endif; ?>

            <h2>User Information:</h2>
            <p>First Name: <?php echo $firstName; ?></p>
            <p>Email Address: <?php echo $emailAddress; ?></p>

            <p>Middle Name: <?php echo $user['middleName']; ?></p>
            <p>Last Name: <?php echo $user['lastName']; ?></p>
            <p>Suffix: <?php echo $user['suffix']; ?></p>
            <p>Birthday: <?php echo $user['birthday']; ?></p>
            <p>Address: <?php echo $user['address']; ?></p>
            <p>Contact Number: <?php echo $user['contactNumber']; ?></p>

            <a class="btn btn-secondary logout-link" href="logout.php">Logout</a>
        <?php else: ?>
            <p>No user details found.</p>
        <?php endif; ?>
    </div>

    <script src="js/bootstrap.min.js"></script>
</body>
</html>